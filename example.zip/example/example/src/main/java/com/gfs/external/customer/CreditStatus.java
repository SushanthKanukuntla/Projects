package com.gfs.external.customer;

public enum CreditStatus {

	HIGH,
	MEDIUM,
	LOW;
}
